#!/bin/bash
#Master submission script for parameter scanning

cd TimeSeparation_1
cd k1
cd sigma1
qsub -l walltime=23:00:00 SubmissionScript.pbs
cd ..
cd sigma05
qsub -l walltime=23:00:00 SubmissionScript.pbs
cd ..
cd sigma01
qsub -l walltime=23:00:00 SubmissionScript.pbs
cd ..
cd ..
cd k2
cd sigma1
qsub -l walltime=23:00:00 SubmissionScript.pbs
cd ..
cd sigma05
qsub -l walltime=23:00:00 SubmissionScript.pbs
cd ..
cd sigma01
qsub -l walltime=23:00:00 SubmissionScript.pbs
cd ..
cd ..
cd k4
cd sigma1
qsub -l walltime=23:00:00 SubmissionScript.pbs
cd ..
cd sigma05
qsub -l walltime=23:00:00 SubmissionScript.pbs
cd ..
cd sigma01
qsub -l walltime=23:00:00 SubmissionScript.pbs
cd ..
cd ..
cd k8
cd sigma1
qsub -l walltime=23:00:00 SubmissionScript.pbs
cd ..
cd sigma05
qsub -l walltime=23:00:00 SubmissionScript.pbs
cd ..
cd sigma01
qsub -l walltime=23:00:00 SubmissionScript.pbs
cd ..
cd ..
cd k16
cd sigma1
qsub -l walltime=23:00:00 SubmissionScript.pbs
cd ..
cd sigma05
qsub -l walltime=23:00:00 SubmissionScript.pbs
cd ..
cd sigma01
qsub -l walltime=23:00:00 SubmissionScript.pbs
cd ..
cd ..
cd ..


cd TimeSeparation_2
cd k1
cd sigma1
qsub -l walltime=23:00:00 SubmissionScript.pbs
cd ..
cd sigma05
qsub -l walltime=23:00:00 SubmissionScript.pbs
cd ..
cd sigma01
qsub -l walltime=23:00:00 SubmissionScript.pbs
cd ..
cd ..
cd k2
cd sigma1
qsub -l walltime=23:00:00 SubmissionScript.pbs
cd ..
cd sigma05
qsub -l walltime=23:00:00 SubmissionScript.pbs
cd ..
cd sigma01
qsub -l walltime=23:00:00 SubmissionScript.pbs
cd ..
cd ..
cd k4
cd sigma1
qsub -l walltime=23:00:00 SubmissionScript.pbs
cd ..
cd sigma05
qsub -l walltime=23:00:00 SubmissionScript.pbs
cd ..
cd sigma01
qsub -l walltime=23:00:00 SubmissionScript.pbs
cd ..
cd ..
cd k8
cd sigma1
qsub -l walltime=23:00:00 SubmissionScript.pbs
cd ..
cd sigma05
qsub -l walltime=23:00:00 SubmissionScript.pbs
cd ..
cd sigma01
qsub -l walltime=23:00:00 SubmissionScript.pbs
cd ..
cd ..
cd k16
cd sigma1
qsub -l walltime=23:00:00 SubmissionScript.pbs
cd ..
cd sigma05
qsub -l walltime=23:00:00 SubmissionScript.pbs
cd ..
cd sigma01
qsub -l walltime=23:00:00 SubmissionScript.pbs
cd ..
cd ..
cd ..

cd TimeSeparation_4
cd k1
cd sigma1
qsub -l walltime=23:00:00 SubmissionScript.pbs
cd ..
cd sigma05
qsub -l walltime=23:00:00 SubmissionScript.pbs
cd ..
cd sigma01
qsub -l walltime=23:00:00 SubmissionScript.pbs
cd ..
cd ..
cd k2
cd sigma1
qsub -l walltime=23:00:00 SubmissionScript.pbs
cd ..
cd sigma05
qsub -l walltime=23:00:00 SubmissionScript.pbs
cd ..
cd sigma01
qsub -l walltime=23:00:00 SubmissionScript.pbs
cd ..
cd ..
cd k4
cd sigma1
qsub -l walltime=23:00:00 SubmissionScript.pbs
cd ..
cd sigma05
qsub -l walltime=23:00:00 SubmissionScript.pbs
cd ..
cd sigma01
qsub -l walltime=23:00:00 SubmissionScript.pbs
cd ..
cd ..
cd k8
cd sigma1
qsub -l walltime=23:00:00 SubmissionScript.pbs
cd ..
cd sigma05
qsub -l walltime=23:00:00 SubmissionScript.pbs
cd ..
cd sigma01
qsub -l walltime=23:00:00 SubmissionScript.pbs
cd ..
cd ..
cd k16
cd sigma1
qsub -l walltime=23:00:00 SubmissionScript.pbs
cd ..
cd sigma05
qsub -l walltime=23:00:00 SubmissionScript.pbs
cd ..
cd sigma01
qsub -l walltime=23:00:00 SubmissionScript.pbs
cd ..
cd ..
cd ..

cd TimeSeparation_8
cd k1
cd sigma1
qsub -l walltime=23:00:00 SubmissionScript.pbs
cd ..
cd sigma05
qsub -l walltime=23:00:00 SubmissionScript.pbs
cd ..
cd sigma01
qsub -l walltime=23:00:00 SubmissionScript.pbs
cd ..
cd ..
cd k2
cd sigma1
qsub -l walltime=23:00:00 SubmissionScript.pbs
cd ..
cd sigma05
qsub -l walltime=23:00:00 SubmissionScript.pbs
cd ..
cd sigma01
qsub -l walltime=23:00:00 SubmissionScript.pbs
cd ..
cd ..
cd k4
cd sigma1
qsub -l walltime=23:00:00 SubmissionScript.pbs
cd ..
cd sigma05
qsub -l walltime=23:00:00 SubmissionScript.pbs
cd ..
cd sigma01
qsub -l walltime=23:00:00 SubmissionScript.pbs
cd ..
cd ..
cd k8
cd sigma1
qsub -l walltime=23:00:00 SubmissionScript.pbs
cd ..
cd sigma05
qsub -l walltime=23:00:00 SubmissionScript.pbs
cd ..
cd sigma01
qsub -l walltime=23:00:00 SubmissionScript.pbs
cd ..
cd ..
cd k16
cd sigma1
qsub -l walltime=23:00:00 SubmissionScript.pbs
cd ..
cd sigma05
qsub -l walltime=23:00:00 SubmissionScript.pbs
cd ..
cd sigma01
qsub -l walltime=23:00:00 SubmissionScript.pbs
cd ..
cd ..
cd ..

cd TimeSeparation_16
cd k1
cd sigma1
qsub -l walltime=23:00:00 SubmissionScript.pbs
cd ..
cd sigma05
qsub -l walltime=23:00:00 SubmissionScript.pbs
cd ..
cd sigma01
qsub -l walltime=23:00:00 SubmissionScript.pbs
cd ..
cd ..
cd k2
cd sigma1
qsub -l walltime=23:00:00 SubmissionScript.pbs
cd ..
cd sigma05
qsub -l walltime=23:00:00 SubmissionScript.pbs
cd ..
cd sigma01
qsub -l walltime=23:00:00 SubmissionScript.pbs
cd ..
cd ..
cd k4
cd sigma1
qsub -l walltime=23:00:00 SubmissionScript.pbs
cd ..
cd sigma05
qsub -l walltime=23:00:00 SubmissionScript.pbs
cd ..
cd sigma01
qsub -l walltime=23:00:00 SubmissionScript.pbs
cd ..
cd ..
cd k8
cd sigma1
qsub -l walltime=23:00:00 SubmissionScript.pbs
cd ..
cd sigma05
qsub -l walltime=23:00:00 SubmissionScript.pbs
cd ..
cd sigma01
qsub -l walltime=23:00:00 SubmissionScript.pbs
cd ..
cd ..
cd k16
cd sigma1
qsub -l walltime=23:00:00 SubmissionScript.pbs
cd ..
cd sigma05
qsub -l walltime=23:00:00 SubmissionScript.pbs
cd ..
cd sigma01
qsub -l walltime=23:00:00 SubmissionScript.pbs
cd ..
cd ..
cd ..

cd TimeSeparation_32
cd k1
cd sigma1
qsub -l walltime=23:00:00 SubmissionScript.pbs
cd ..
cd sigma05
qsub -l walltime=23:00:00 SubmissionScript.pbs
cd ..
cd sigma01
qsub -l walltime=23:00:00 SubmissionScript.pbs
cd ..
cd ..
cd k2
cd sigma1
qsub -l walltime=23:00:00 SubmissionScript.pbs
cd ..
cd sigma05
qsub -l walltime=23:00:00 SubmissionScript.pbs
cd ..
cd sigma01
qsub -l walltime=23:00:00 SubmissionScript.pbs
cd ..
cd ..
cd k4
cd sigma1
qsub -l walltime=23:00:00 SubmissionScript.pbs
cd ..
cd sigma05
qsub -l walltime=23:00:00 SubmissionScript.pbs
cd ..
cd sigma01
qsub -l walltime=23:00:00 SubmissionScript.pbs
cd ..
cd ..
cd k8
cd sigma1
qsub -l walltime=23:00:00 SubmissionScript.pbs
cd ..
cd sigma05
qsub -l walltime=23:00:00 SubmissionScript.pbs
cd ..
cd sigma01
qsub -l walltime=23:00:00 SubmissionScript.pbs
cd ..
cd ..
cd k16
cd sigma1
qsub -l walltime=23:00:00 SubmissionScript.pbs
cd ..
cd sigma05
qsub -l walltime=23:00:00 SubmissionScript.pbs
cd ..
cd sigma01
qsub -l walltime=23:00:00 SubmissionScript.pbs
cd ..
cd ..
cd ..




