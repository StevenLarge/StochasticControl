#Thie parameter file contains the read path for the stochastic control simualtions contained in this file

#READPATH = '/home/slarge/StochasticControlApril12/dLambda_80/Trajectories_a95/'

READPATH = 'Trajectories_a95/'
