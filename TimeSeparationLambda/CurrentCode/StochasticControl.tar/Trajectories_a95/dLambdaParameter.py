#dLambda parameter value

Dist = 80
