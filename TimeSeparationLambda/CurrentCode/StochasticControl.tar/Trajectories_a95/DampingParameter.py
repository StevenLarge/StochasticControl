#Damping parameter value

a = 0.950000
