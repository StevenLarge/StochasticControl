#Parameters for Stochastic Control Simulations

k = 32
beta=1
m=1
dt=0.1
a=0.25

