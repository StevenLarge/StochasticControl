#This module generates the parameter.py files in the secondary level of the time-separation stochastic control 
#structure
#
#Steven Large
#December 27th 2016

import os





