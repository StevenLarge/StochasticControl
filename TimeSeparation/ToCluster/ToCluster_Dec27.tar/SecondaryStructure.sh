#!/bin/bash
#This script generates the seconadry level of structure in the time separation simulations, testing how the work 
#changes with the spring constants

mkdir k1
mkdir k2
mkdir k4
mkdir k8
mkdir k16

tar -cvf SecondLevel.tar *.py

cp SecondLevel.tar k1
cp SecondLevel.tar k2
cp SecondLevel.tar k4
cp SecondLevel.tar k8
cp SecondLevel.tar k16

cd k1
tar -xvf *.tar
python SecondaryParameters.py
cd ..

cd k2
tar -xvf *.tar
python SecondaryParameters.py
cd ..

cd k4
tar -xvf *.tar
python SecondaryParameters.py
cd ..

cd k8
tar -xvf *.tar
python SecondaryParameters.py
cd ..

cd k16
tar -xvf *.tar
python SecondaryParameters.py
cd ..
