#!/bin/bash
#This script submits the jobs to the cluster

cd Times_5
qsub -l walltime=36:00:00 SubmissionScript.pbs
cd ..

cd Times_10
qsub -l walltime=36:00:00 SubmissionScript.pbs
cd ..

cd Times_20
qsub -l walltime=36:00:00 SubmissionScript.pbs
cd ..

cd Times_40
qsub -l walltime=36:00:00 SubmissionScript.pbs
cd ..

cd Times_80
qsub -l walltime=47:00:00 SubmissionScript.pbs
cd ..

cd Times_160
qsub -l walltime=47:00:00 SubmissionScript.pbs
cd ..

