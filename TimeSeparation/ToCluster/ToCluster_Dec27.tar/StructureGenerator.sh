#!/bin/bash
#This script generates the file structure for running time separation simuations on the cluster

mkdir Times_5
mkdir Times_10
mkdir Times_20
mkdir Times_40
mkdir Times_80
mkdir Times_160

cp *.py Times_5
cp *.py Times_10
cp *.py Times_20
cp *.py Times_40
cp *.py Times_80
cp *.py Times_160

python TimeParameterMasterWrite.py

cd Times_5
mkdir Output
rm TimeParameterMasterWrite.py
python GeneratePBS.py
rm GeneratePBS.py
cd ..

cd Times_10
mkdir Output
rm TimeParameterMasterWrite.py
python GeneratePBS.py
rm GeneratePBS.py
cd ..

cd Times_20
mkdir Output
rm TimeParameterMasterWrite.py
python GeneratePBS.py
rm GeneratePBS.py
cd .. 

cd Times_40
mkdir Output
rm TimeParameterMasterWrite.py
python GeneratePBS.py
rm GeneratePBS.py
cd ..

cd Times_80
mkdir Output
rm TimeParameterMasterWrite.py
python GeneratePBS.py
rm GeneratePBS.py
cd ..

cd Times_160
mkdir Output
rm TimeParameterMasterWrite.py
python GeneratePBS.py
rm GeneratePBS.py
cd ..
