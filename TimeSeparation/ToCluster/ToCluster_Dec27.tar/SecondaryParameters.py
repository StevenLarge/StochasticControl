#This module generates the parameter.py files in the secondary level of the time-separation stochastic control 
#structure
#
#Steven Large
#December 27th 2016

def WriteParameterFile(kCP):

	filename = 'Parameters.py'

	file1 = open(filename,'w')
	file1.write('#Parameters File\n\nk=1\na=0.25\nbeta=1\nm=1\n\ndt=0.1\n\nkCP=%lf\nDist=50\nsigma=1\n' % kCP)
	file1.close()

	return None

Springs = [1,2,4,8,16]

for k in range(len(Springs)):

	WriteParameterFile(Springs[k])



