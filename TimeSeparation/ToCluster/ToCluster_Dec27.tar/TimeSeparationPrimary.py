#This module provides the main script for various time separations of the underlying system dynamics and the control parameter
#
#Steven Large
#December17th 2016

import TimeDriver
from math import *
from Parameters import *
from TimeParameters import *
import random
import WriteData

import numpy as np
#import matplotlib.pyplot as plt

NumberTrajectories = 100
TimeRange = 70


WorkDTot = []
WorkSTot = []
WorkDeterministic = []
WorkStochastic = []
WorkTotal = []
Tau = []

CPTime = []
InternalTime = []

filename_D = 'WorkDeterministic_TS_' + str(TimeSeparation) + '.dat'
filename_S = 'WorkStochastic_TS_' + str(TimeSeparation) + '.dat'
filename_T = 'WorkTotal_TS_' + str(TimeSeparation) + '.dat'

#filename_BasePosition = 'PosTrack_'
#filename_BaseVelocity = 'VelTrack_'
#filename_BaseCP = 'CPTrack_'

path = 'Output/'

filename_Times = 'Times_' + str(TimeSeparation) + '.dat'

for index in range(TimeRange):

	ProtocolTime = 100 + 50*index

	Tau.append(ProtocolTime)

	#print('Protocol Time --> %lf\n' % ProtocolTime)

	WorkDTot.append(0.0)
	WorkSTot.append(0.0)

	for Realizations in range(NumberTrajectories):

		WorkD, WorkS, PositionTrack, VelocityTrack, CPTrack, OuterTime, InnerTime = TimeDriver.Propogator(ProtocolTime,TimeSeparation)

		#if Realizations==1:

			#plt.plot(PositionTrack)
			#plt.show()
			#plt.xlabel('Time Step')
			#plt.ylabel('System Position')
			#plt.close()

			#plt.plot(CPTrack)
			#plt.show()
			#plt.xlabel('Time Step')
			#plt.ylabel('Control Parameter Position')
			#plt.close()

		WorkDTot[index] = WorkDTot[index] + WorkD
		WorkSTot[index] = WorkSTot[index] + WorkS
		
	CPTime.append(OuterTime)
	InternalTime.append(InnerTime)

for index in range(len(WorkDTot)):

	WorkDeterministic.append(WorkDTot[index]/float(NumberTrajectories))
	WorkStochastic.append(WorkSTot[index]/float(NumberTrajectories))
	
	WorkTotal.append(WorkDeterministic[index] + WorkStochastic[index])

WriteData.WorkWrite(WorkDeterministic,Tau,filename_D,path)
WriteData.WorkWrite(WorkStochastic,Tau,filename_S,path)
WriteData.WorkWrite(WorkTotal,Tau,filename_T,path)

WriteData.TimeWrite(CPTime,InternalTime,filename_Times,path)


