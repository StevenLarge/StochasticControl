#!/bin/bash
#This shell script is the master submission script for the Time Separation stochastic control simulations

qsub -l walltime=36:00:00 Times_1/k1/SubmissionScript.pbs
qsub -l walltime=36:00:00 Times_1/k2/SubmissionScript.pbs
qsub -l walltime=36:00:00 Times_1/k4/SubmissionScript.pbs
qsub -l walltime=36:00:00 Times_1/k8/SubmissionScript.pbs
qsub -l walltime=36:00:00 Times_1/k16/SubmissionScript.pbs

qsub -l walltime=36:00:00 Times_5/k1/SubmissionScript.pbs
qsub -l walltime=36:00:00 Times_5/k2/SubmissionScript.pbs
qsub -l walltime=36:00:00 Times_5/k4/SubmissionScript.pbs
qsub -l walltime=36:00:00 Times_5/k8/SubmissionScript.pbs
qsub -l walltime=36:00:00 Times_5/k16/SubmissionScript.pbs

qsub -l walltime=36:00:00 Times_10/k1/SubmissionScript.pbs
qsub -l walltime=36:00:00 Times_10/k2/SubmissionScript.pbs
qsub -l walltime=36:00:00 Times_10/k4/SubmissionScript.pbs
qsub -l walltime=36:00:00 Times_10/k8/SubmissionScript.pbs
qsub -l walltime=36:00:00 Times_10/k16/SubmissionScript.pbs

qsub -l walltime=36:00:00 Times_20/k1/SubmissionScript.pbs
qsub -l walltime=36:00:00 Times_20/k2/SubmissionScript.pbs
qsub -l walltime=36:00:00 Times_20/k4/SubmissionScript.pbs
qsub -l walltime=36:00:00 Times_20/k8/SubmissionScript.pbs
qsub -l walltime=36:00:00 Times_20/k16/SubmissionScript.pbs

qsub -l walltime=36:00:00 Times_40/k1/SubmissionScript.pbs
qsub -l walltime=36:00:00 Times_40/k2/SubmissionScript.pbs
qsub -l walltime=36:00:00 Times_40/k4/SubmissionScript.pbs
qsub -l walltime=36:00:00 Times_40/k8/SubmissionScript.pbs
qsub -l walltime=36:00:00 Times_40/k16/SubmissionScript.pbs

qsub -l walltime=36:00:00 Times_80/k1/SubmissionScript.pbs
qsub -l walltime=36:00:00 Times_80/k2/SubmissionScript.pbs
qsub -l walltime=36:00:00 Times_80/k4/SubmissionScript.pbs
qsub -l walltime=36:00:00 Times_80/k8/SubmissionScript.pbs
qsub -l walltime=36:00:00 Times_80/k16/SubmissionScript.pbs

qsub -l walltime=36:00:00 Times_160/k1/SubmissionScript.pbs
qsub -l walltime=36:00:00 Times_160/k2/SubmissionScript.pbs
qsub -l walltime=36:00:00 Times_160/k4/SubmissionScript.pbs
qsub -l walltime=36:00:00 Times_160/k8/SubmissionScript.pbs
qsub -l walltime=36:00:00 Times_160/k16/SubmissionScript.pbs





