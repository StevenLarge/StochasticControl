#This is a master module which writes the TimeParameter.py files to the correct substructure for stochastic control 
#simulations
#
#Steven Large
#February 1st 2017

import os

Times = ['TimeSeparation_200/','TimeSeparation_250/','TimeSeparation_300/','TimeSeparation_350/','TimeSeparation_400/','TimeSeparation_450/','TimeSeparation_500/']

NumberTimes = [200, 250, 300, 350, 400, 450, 500]

filename_base = 'TimeParameters.py'

for index1 in range(len(Times)):

	CompleteName = os.path.join(Times[index1],filename_base)

	file1 = open(CompleteName,'w')
	file1.write('#Time Separation Parameter for Stochastic Control Simulation\n')
	file1.write('TimeSeparation = %d' % NumberTimes[index1])
	file1.close()



