#!/bin/bash
#This is the submission script for Time Separation simualtions submitted on January 23rd 2017

cd TimeSeparation_200
qsub -l walltime=32:00:00 SubmissionScript.pbs
cd ..

cd TimeSeparation_250
qsub -l walltime=32:00:00 SubmissionScript.pbs
cd ..

cd TimeSeparation_300
qsub -l walltime=32:00:00 SubmissionScript.pbs
cd ..

cd TimeSeparation_350
qsub -l walltime=32:00:00 SubmissionScript.pbs
cd ..

cd TimeSeparation_400
qsub -l walltime=32:00:00 SubmissionScript.pbs
cd ..

cd TimeSeparation_450
qsub -l walltime=32:00:00 SubmissionScript.pbs
cd ..

cd TimeSeparation_500
qsub -l walltime=32:00:00 SubmissionScript.pbs
cd ..