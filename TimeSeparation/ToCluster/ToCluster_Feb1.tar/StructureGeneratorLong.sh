#!/bin/bash
#StructureGenerator for Time Separation Simulations January 23rd 2017

mkdir TimeSeparation_200
mkdir TimeSeparation_250
mkdir TimeSeparation_300
mkdir TimeSeparation_350
mkdir TimeSeparation_400
mkdir TimeSeparation_450
mkdir TimeSeparation_500

tar -cvf Scripts.tar TimePrimary.py Parameters.py GeneratePBS.py GeneratePBSFriction.py TimeDriverLocal.py WriteData.py WorkTheoryModule.py Potential.py LangevinPropogator.py FrictionCalculation.py FrictionTestPrimary.py

cp Scripts.tar TimeSeparation_200/Scripts.tar
cp Scripts.tar TimeSeparation_250/Scripts.tar
cp Scripts.tar TimeSeparation_300/Scripts.tar
cp Scripts.tar TimeSeparation_350/Scripts.tar
cp Scripts.tar TimeSeparation_400/Scripts.tar
cp Scripts.tar TimeSeparation_450/Scripts.tar
cp Scripts.tar TimeSeparation_500/Scripts.tar

rm *.tar

cd TimeSeparation_200
mkdir Output
tar -xvf *.tar
python GeneratePBS.py
rm *.tar
cd ..

cd TimeSeparation_250
mkdir Output
tar -xvf *.tar
python GeneratePBS.py
rm *.tar
cd ..

cd TimeSeparation_300
mkdir Output
tar -xvf *.tar
python GeneratePBS.py
rm *.tar
cd ..

cd TimeSeparation_350
mkdir Output
tar -xvf *.tar
python GeneratePBS.py
rm *.tar
cd ..

cd TimeSeparation_400
mkdir Output
tar -xvf *.tar
python GeneratePBS.py
rm *.tar
cd ..

cd TimeSeparation_450
mkdir Output
tar -xvf *.tar
python GeneratePBS.py
rm *.tar
cd ..

cd TimeSeparation_500
mkdir Output
tar -xvf *.tar
python GeneratePBS.py
rm *.tar
cd ..


python TimeParameterMasterWriteLong.py


echo ""
echo ""
echo ""
echo ""
echo ""
echo "-----File Structure generated-----"
echo ""
echo ""
echo ""
echo ""
echo ""
