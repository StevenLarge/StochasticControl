#This module is a writes the TimeParamters.py file into subdirectories for different time separations
#
#Steven Large
#December 22nd 2016

import os

TimeSeparations = [5,10,20,40,80,160]
WritePaths = []

BaseName = 'TimeParameters.py'

for k in range(len(TimeSeparations)):

	WritePaths.append('Times_' + str(TimeSeparations[k]) + '/')

for k in range(len(WritePaths)):

	CompleteName = os.path.join(WritePaths[k] + BaseName)

	file1 = open(CompleteName,'w')
	file1.write('TimeSeparation = %d\n' % TimeSeparations[k])
	file1.close()



