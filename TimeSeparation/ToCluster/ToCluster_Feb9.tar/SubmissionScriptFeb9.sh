#!/bin/bash
#Submission Script for February 9th

cd TimeSeparation_1
cd kCP_1
qsub -l walltime=10:00:00 SubmissionScript.pbs
cd ..
cd kCP_2
qsub -l walltime=10:00:00 SubmissionScript.pbs
cd ..
cd kCP_4
qsub -l walltime=10:00:00 SubmissionScript.pbs
cd ..
cd kCP_8
qsub -l walltime=10:00:00 SubmissionScript.pbs
cd ..
cd kCP_16
qsub -l walltime=10:00:00 SubmissionScript.pbs
cd ..
cd kCP_32
qsub -l walltime=10:00:00 SubmissionScript.pbs
cd ..
cd ..

cd TimeSeparation_2
cd kCP_1
qsub -l walltime=10:00:00 SubmissionScript.pbs
cd ..
cd kCP_2
qsub -l walltime=10:00:00 SubmissionScript.pbs
cd ..
cd kCP_4
qsub -l walltime=10:00:00 SubmissionScript.pbs
cd ..
cd kCP_8
qsub -l walltime=10:00:00 SubmissionScript.pbs
cd ..
cd kCP_16
qsub -l walltime=10:00:00 SubmissionScript.pbs
cd ..
cd kCP_32
qsub -l walltime=10:00:00 SubmissionScript.pbs
cd ..
cd ..


cd TimeSeparation_4
cd kCP_1
qsub -l walltime=10:00:00 SubmissionScript.pbs
cd ..
cd kCP_2
qsub -l walltime=10:00:00 SubmissionScript.pbs
cd ..
cd kCP_4
qsub -l walltime=10:00:00 SubmissionScript.pbs
cd ..
cd kCP_8
qsub -l walltime=10:00:00 SubmissionScript.pbs
cd ..
cd kCP_16
qsub -l walltime=10:00:00 SubmissionScript.pbs
cd ..
cd kCP_32
qsub -l walltime=10:00:00 SubmissionScript.pbs
cd ..
cd ..


cd TimeSeparation_8
cd kCP_1
qsub -l walltime=15:00:00 SubmissionScript.pbs
cd ..
cd kCP_2
qsub -l walltime=15:00:00 SubmissionScript.pbs
cd ..
cd kCP_4
qsub -l walltime=15:00:00 SubmissionScript.pbs
cd ..
cd kCP_8
qsub -l walltime=15:00:00 SubmissionScript.pbs
cd ..
cd kCP_16
qsub -l walltime=15:00:00 SubmissionScript.pbs
cd ..
cd kCP_32
qsub -l walltime=15:00:00 SubmissionScript.pbs
cd ..
cd ..


cd TimeSeparation_16
cd kCP_1
qsub -l walltime=20:00:00 SubmissionScript.pbs
cd ..
cd kCP_2
qsub -l walltime=20:00:00 SubmissionScript.pbs
cd ..
cd kCP_4
qsub -l walltime=20:00:00 SubmissionScript.pbs
cd ..
cd kCP_8
qsub -l walltime=20:00:00 SubmissionScript.pbs
cd ..
cd kCP_16
qsub -l walltime=20:00:00 SubmissionScript.pbs
cd ..
cd kCP_32
qsub -l walltime=20:00:00 SubmissionScript.pbs
cd ..
cd ..


cd TimeSeparation_32
cd kCP_1
qsub -l walltime=25:00:00 SubmissionScript.pbs
cd ..
cd kCP_2
qsub -l walltime=25:00:00 SubmissionScript.pbs
cd ..
cd kCP_4
qsub -l walltime=25:00:00 SubmissionScript.pbs
cd ..
cd kCP_8
qsub -l walltime=25:00:00 SubmissionScript.pbs
cd ..
cd kCP_16
qsub -l walltime=25:00:00 SubmissionScript.pbs
cd ..
cd kCP_32
qsub -l walltime=25:00:00 SubmissionScript.pbs
cd ..
cd ..


cd TimeSeparation_64
cd kCP_1
qsub -l walltime=30:00:00 SubmissionScript.pbs
cd ..
cd kCP_2
qsub -l walltime=30:00:00 SubmissionScript.pbs
cd ..
cd kCP_4
qsub -l walltime=30:00:00 SubmissionScript.pbs
cd ..
cd kCP_8
qsub -l walltime=30:00:00 SubmissionScript.pbs
cd ..
cd kCP_16
qsub -l walltime=30:00:00 SubmissionScript.pbs
cd ..
cd kCP_32
qsub -l walltime=30:00:00 SubmissionScript.pbs
cd ..
cd ..

