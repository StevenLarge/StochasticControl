#!/bin/bash
#This is the submission script for Time Separation simualtions submitted on January 23rd 2017

cd TimeSeparation_1
qsub -l walltime=23:00:00 SubmissionScript.pbs
cd ..

cd TimeSeparation_2
qsub -l walltime=23:00:00 SubmissionScript.pbs
cd ..

cd TimeSeparation_4
qsub -l walltime=23:00:00 SubmissionScript.pbs
cd ..

cd TimeSeparation_8
qsub -l walltime=23:00:00 SubmissionScript.pbs
cd ..

cd TimeSeparation_16
qsub -l walltime=23:00:00 SubmissionScript.pbs
cd ..

cd TimeSeparation_32
qsub -l walltime=23:00:00 SubmissionScript.pbs
cd ..

cd TimeSeparation_64
qsub -l walltime=32:00:00 SubmissionScript.pbs
cd ..

cd TimeSeparation_128
qsub -l walltime=32:00:00 SubmissionScript.pbs
cd ..

cd TimeSeparation_1
qsub -l walltime=3:00:00 SubmissionScriptFriction.pbs
cd ..

cd TimeSeparation_2
qsub -l walltime=3:00:00 SubmissionScriptFriction.pbs
cd ..

cd TimeSeparation_4
qsub -l walltime=3:00:00 SubmissionScriptFriction.pbs
cd ..

cd TimeSeparation_8
qsub -l walltime=3:00:00 SubmissionScriptFriction.pbs
cd ..

cd TimeSeparation_16
qsub -l walltime=3:00:00 SubmissionScriptFriction.pbs
cd ..

cd TimeSeparation_32
qsub -l walltime=8:00:00 SubmissionScriptFriction.pbs
cd ..

cd TimeSeparation_64
qsub -l walltime=8:00:00 SubmissionScriptFriction.pbs
cd ..

cd TimeSeparation_128
qsub -l walltime=8:00:00 SubmissionScriptFriciton.pbs
cd ..
