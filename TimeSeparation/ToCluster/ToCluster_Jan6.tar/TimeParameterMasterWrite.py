#This is a master module which writes the TimeParameter.py files to the correct substructure for stochastic control 
#simulations
#
#Steven Large
#January 4th 2017

import os

Times = ['Times_1/','Times_5/','Times_10/','Times_20/','Times_40/','Times_80/','Times_160/']

NumberTimes = [1, 5, 10, 20, 40, 80, 160]

Springs = ['k1/','k2/','k4/','k8/','k16/']

filename_base = 'TimeParameters.py'

for index1 in range(len(Times)):

	for index2 in range(len(Springs)):

		SecondName = os.path.join(Springs[index2],filename_base)
		CompleteName = os.path.join(Times[index1],SecondName)

		file1 = open(CompleteName,'w')
		file1.write('#Time Separation Parameter for Stochastic Control Simulation\n')
		file1.write('TimeSeparation = %lf' % NumberTimes[index1])
		file1.close()



