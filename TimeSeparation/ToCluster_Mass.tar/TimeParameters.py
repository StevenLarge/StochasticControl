#This module contains the time separation factor between the system and control parameter dyanamics for Stochastic 
#control simulations
#
#Steven Large
#December 17th 2016


TimeSeparation = 1


