#This is the parameter file for Langevin Simulations
#
#Steven Large
#June 21st 2016

k=2
a=0.25
beta=1

m = 1
mCP = 1

aCP = 0.25

dt=0.1

kCP=1
Dist=10
sigma=1
 