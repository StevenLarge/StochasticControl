#This is the driver routine for the constant velocity simualtions
#
#Steven Large
#January 4th 2016

from math import *
from Parameters import *
from LangevinPropogator import *
import random
import numpy

def Propogator(ProtocolTime, VelocityVariance):

	time = 0
	position = 0
	velocity = 0
	WorkAcc = 0

	CP = 0

	CPVel_MEAN = float(Dist)/float(ProtocolTime)

	CPVel = random.gauss(CPVel_MEAN, sqrt(VelocityVariance))

	Equilibration = 100 							 			

	while time < Equilibration:

		(time, position, velocity, WorkStep, CP) = LangevinConstantCPVelocity(time, position, velocity, CP, CPVel)

	position = position - CPVel*Equilibration
	CP = CP - CPVel*Equilibration

	time = 0

	while time < ProtocolTime:

			(time, position, velocity, WorkStep, CP) = LangevinConstantCPVelocity(time, position, velocity, CP, CPVel)
			WorkAcc = WorkAcc + WorkStep

	return WorkAcc




