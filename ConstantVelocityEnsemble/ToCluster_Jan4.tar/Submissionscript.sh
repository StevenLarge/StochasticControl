#!/bin/bash
#This is the master submission script for the constant velocity ensemble

qsub -l walltime=10:00:00 VelVar_01/SubmissionScript.pbs
qsub -l walltime=10:00:00 VelVar_05/SubmissionScript.pbs
qsub -l walltime=10:00:00 VelVar_1/SubmissionScript.pbs
qsub -l walltime=10:00:00 VelVar_2/SubmissionScript.pbs
qsub -l walltime=10:00:00 VelVar_4/SubmissionScript.pbs
qsub -l walltime=10:00:00 VelVar_8/SubmissionScript.pbs




