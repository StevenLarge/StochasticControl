#This module contains the Velocity Variance Parameter

VelocityVariance = 1